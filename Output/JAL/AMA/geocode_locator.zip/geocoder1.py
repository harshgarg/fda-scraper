import xlrd
import geocoder
import json

workbook = xlrd.open_workbook("output.xlsx")
sh = workbook.sheet_by_index(0)

dict1 = {}

for n in range(sh.nrows):
  add = sh.cell_value(n,2)
  g = geocoder.google(add)
  dict1[add] = g.latlng


f = open("result.txt","w")
json.dump(dict1,f)
f.close()

